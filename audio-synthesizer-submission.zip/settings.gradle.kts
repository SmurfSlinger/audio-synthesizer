rootProject.name = "audio-synthesizer"
